import java.util.*;
import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
public class assignment4 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
		//ִ�е��߳�
		long st=System.currentTimeMillis();
		OneThread one=new OneThread();
		Thread td=new Thread(one);
		td.start();
		long end=System.currentTimeMillis();
		System.out.println("the start time is :"+st+"\n"
				+"the end time is:"+end+"\n"+
				"all time is:"+(end-st));
		//���̣߳���һ���ظ�ִ�У��ʷ����߳�����ִ�С�
		// ��ȥ����ҳ�����100����ʦ�ĸ�����ҳ������
		long st1=System.currentTimeMillis();
		String baseUrl="http://staff.whu.edu.cn/";
		Vector<String> all_links=new Vector<String>();
		Pattern p=Pattern.compile("(show\\.jsp\\?lang=cn\\&n=[\\w+\\s]+)");
		Document doc=Jsoup.connect("http://staff.whu.edu.cn/").get();
		Elements links=doc.select("a[href]");
		for(Element link:links){
			String str=link.attr("abs:href");
			Matcher m=p.matcher(str);
			while(m.find()){
				all_links.add(baseUrl+m.group());
			}
		}
		for(String url:all_links){
			MoreThread more=new MoreThread(url);
			Thread th=new Thread(more);
			th.start();
		}
		long end1=System.currentTimeMillis();
		System.out.println("the moreThread start at:"+st1+
				"\n"+"the end time is :"+end1+"\n"+
				"all time is: "+(end1-st1));
		
	}

}
 class message {
	public int id;
	public String name;
	public String research;
	public String award;
	public message(String a,String b,String c){
		name=a;
		research=b;
		award=c;
	}
}
 class OneThread implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		String baseUrl="http://staff.whu.edu.cn/";
		Vector<String> all_links=new Vector<String>();
		Vector<message> all_messages=new Vector<message>();
		Pattern p=Pattern.compile("(show\\.jsp\\?lang=cn\\&n=[\\w+\\s]+)");
		try {
			Document doc = Jsoup.connect("http://staff.whu.edu.cn/").get();
			Elements links=doc.select("a[href]");
			for(Element link:links){
				String str=link.attr("abs:href");
				Matcher m=p.matcher(str);
				while(m.find()){
					all_links.add(baseUrl+m.group());
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//�ֱ���ȥ100����ҳ����ȡ��Ϣ
		for(String str:all_links){
			try {
				Document doc1 = Jsoup.connect(str).get();
				String name=doc1.select("h1").first().text();
				Document doc2=Jsoup.connect(str+"&f=intruction").get();
				Elements research=doc2.select("p");
				String research1="";
				for(Element ele:research){
					research1+=ele.text()+"\t";
				}
				if(research1.equals("")){
					continue;
				}
				Document doc3=Jsoup.connect(str+"&f=awards").get();
				Elements award=doc3.select("p");
				String award1="";
				for(Element ele: award){
					award1+=ele.text()+"\t";
				}
				if(award1.equals("")){
					continue;
				}
				message m=new message(name,research1,award1);
				all_messages.add(m);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		//�������ݿ�
			String driver="com.mysql.jdbc.Driver";
			String url="jdbc:mysql://127.0.0.1:3306/mydatabase?seUnicode=true&characterEncoding=UTF-8";
			String user="root";
			String password="123456";
			try {
				Class.forName(driver);
				Connection conn=DriverManager.getConnection(url, user, password);
				if(!conn.isClosed()){
					Statement statement2=conn.createStatement();
					for(int i=0;i<all_messages.size();i++){
						String sqlexcute="INSERT INTO `mydatabase`.`one_thread` (`name`, `research`, `award`) VALUES ('"+all_messages.get(i).name+"', '"+all_messages.get(i).research+"', '"+all_messages.get(i).award+"');";
						statement2.executeUpdate(sqlexcute);
					}
					conn.close();
				}
			}catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
	}
 }
 class MoreThread implements Runnable{
	public String url;
	public MoreThread(String u){
		url=u;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			Document doc1 = Jsoup.connect(url).get();
			String name=doc1.select("h1").first().text();
			Document doc2=Jsoup.connect(url+"&f=intruction").get();
			Elements research=doc2.select("p");
			String research1="";
			for(Element ele:research){
				research1+=ele.text()+"\t";
			}
			if(research1.equals("")){
				return;
			}
			Document doc3=Jsoup.connect(url+"&f=awards").get();
			Elements award=doc3.select("p");
			String award1="";
			for(Element ele: award){
				award1+=ele.text()+"\t";
			}
			if(award1.equals("")){
				return;
			}
			String driver="com.mysql.jdbc.Driver";
			String url="jdbc:mysql://127.0.0.1:3306/mydatabase?seUnicode=true&characterEncoding=UTF-8";
			String user="root";
			String password="123456";
			Class.forName(driver);
			Connection conn=DriverManager.getConnection(url, user, password);
			if(!conn.isClosed()){
				Statement statement2=conn.createStatement();
				String sqlexcute="INSERT INTO `mydatabase`.`more_thread` (`name`, `research`, `award`) VALUES ('"+name+"', '"+research1+"', '"+award1+"');";
				statement2.executeUpdate(sqlexcute);
				conn.close();
			}
		} catch (IOException | ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	 
 }
