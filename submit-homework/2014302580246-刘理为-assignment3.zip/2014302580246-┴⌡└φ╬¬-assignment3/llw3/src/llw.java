import java.util.*;
import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
public class llw{
	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException
	{
		long startTime=System.currentTimeMillis();
		OneThread one = new OneThread();
		Thread td=new Thread(one);
		td.start();
		long end=System.currentTimeMillis();
		System.out.println("the start time is :"+startTime+"\n"
				+"the end time is:"+end+"\n"+
				"all time is:"+(end-startTime));
     }
static class table{
	public String name;
	public String program;
	public table(String a,String b){
		name=a;
		program=b;
	};
	
}
static class OneThread implements Runnable{
	@Override
	public void run() {
		String basicalUrl="http://staff.whu.edu.cn/";
		Vector<String> a_links=new Vector<String>();
		Vector<table> a_table=new Vector<table>();
		Pattern p=Pattern.compile("(show\\.jsp\\?lang=cn\\&n=[\\w+\\s]+)");
		try {
			Document doc = Jsoup.connect("http://staff.whu.edu.cn/").get();
			Elements links=doc.select("a[href]");
			for(Element link:links){
				String str=link.attr("abs:href");
				Matcher m=p.matcher(str);
				while(m.find()){
					a_links.add(basicalUrl+m.group());
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	
		for(String str:a_links){
			try {
				Document doc1 = Jsoup.connect(str).get();
				String name=doc1.select("h1").first().text();
				Document doc2=Jsoup.connect(str+"&f=research").get();
				Elements program=doc2.select("p");
				String program1="";
				for(Element ele:program){
					program1+=ele.text()+"\t";
				}
				if(program1.equals("")){
					continue;
				}
				table t=new table(name,program1);
				a_table.add(t);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			
		}
			String driver="com.mysql.jdbc.Driver";
			String url="jdbc:mysql://localhost:3306/llw";
			String user="root";
			String password="123456";
			try {
				Class.forName(driver);
				Connection conn=DriverManager.getConnection(url, user, password);
				if(!conn.isClosed()){
					Statement statement2=conn.createStatement();
					for(int i=0;i<a_table.size();i++){
						String sqlexcute="INSERT INTO `llw`.`table1` (`name`, `program`) VALUES ('"+a_table.get(i).name+"', '"+a_table.get(i).program+"');";
						statement2.executeUpdate(sqlexcute);
					}
					conn.close();
				}
			}catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			
	}
 }

}